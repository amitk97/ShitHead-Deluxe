import {Euler, Quaternion} from 'three';

/** Reference-preserving runtime facial controller. No game or account integration. */
export const clamp = (x, a=0, b=1) => Math.max(a, Math.min(b, x));
export const smooth = (a,b,t) => {const x=clamp((t-a)/(b-a)); return x*x*(3-2*x);};
const pulse=(a,b,c,d,t)=>smooth(a,b,t)*(1-smooth(c,d,t));
const TAU=Math.PI*2;
export const MODES={idle:6,laugh:2.8,tongue:2.8,speak:6.46,burn:2.12,turntable:8,demo:16.1};
const aliases={jawOpen:['jawOpen','Jaw open'],smile:['smile','Lip sneer'],pucker:['pucker','Lip pucker'],blinkLeft:['blinkLeft','Left squint'],blinkRight:['blinkRight','Right squint'],browRaise:['browRaise','Brow quirk'],cheekRaise:['cheekRaise'],tongueOut:['tongueOut','Tongue extension'],tongueCurl:['tongueCurl','Tongue curl']};
export class CharacterController{
  constructor(gltf,{words=[],reducedMotion=false}={}){
    this.scene=gltf.scene;this.words=words;this.reducedMotion=reducedMotion;
    this.mode='idle';this.time=0;this.faceOverride=null;this.morphs=[];this.nodes={};this.boneRest=new Map();
    this.scene.traverse(o=>{this.nodes[o.name]=o;if(o.isBone)this.boneRest.set(o,o.quaternion.clone());if(o.morphTargetInfluences)this.morphs.push(o);});
    this.rest={position:this.scene.position.clone(),quaternion:this.scene.quaternion.clone(),scale:this.scene.scale.clone()};
    this.disposed=false;this.last={mode:'idle',time:0,face:{}};
  }
  setMode(name){if(!(name in MODES))throw new Error('Unknown mascot mode: '+name);this.mode=name;this.time=0;this.faceOverride=null;return this;}
  setFace(values){this.faceOverride=values?{...values}:null;return this;}
  applyFace(face){
    for(const mesh of this.morphs){mesh.morphTargetInfluences.fill(0);const dict=mesh.morphTargetDictionary;for(const[name,value]of Object.entries(face)){for(const alias of aliases[name]||[name]){if(dict[alias]!==undefined){mesh.morphTargetInfluences[dict[alias]]=clamp(value);break;}}}}
  }
  speechFace(t){
    const face={jawOpen:0,pucker:0,smile:.10,cheekRaise:.05,browRaise:.09};
    for(const word of this.words){
      const start=word.offset/1e7,duration=Math.max(.04,word.duration/1e7),u=(t-start)/duration;if(u<0||u>1)continue;
      const chars=word.text.toLowerCase().replace(/[^a-z]/g,''),idx=Math.min(chars.length-1,Math.floor(u*chars.length)),ch=chars[idx]||'a';
      const envelope=Math.sin(Math.PI*u)**.6,syllables=Math.max(1,(chars.match(/[aeiouy]+/g)||[]).length);
      face.jawOpen=envelope*(.23+.23*Math.sin(u*syllables*Math.PI)**2);
      if('ouqw'.includes(ch)){face.pucker=.55*envelope;face.smile=0;}
      if('eiy'.includes(ch)){face.smile=.40*envelope;face.cheekRaise=.18*envelope;}
      if('mbp'.includes(ch))face.jawOpen*=.10;
      if('fv'.includes(ch))face.jawOpen*=.45;
      face.browRaise=.12+.17*envelope;
      break;
    }return face;
  }
  sample(t){
    if(this.disposed)return this.last;
    this.time=Math.max(0,t);let mode=this.mode,age=this.time;
    if(mode==='demo'){
      if(age<1.2){mode='idle';}
      else if(age<7.66){mode='speak';age-=1.2;}
      else if(age<10.46){mode='tongue';age-=7.66;}
      else if(age<13.26){mode='laugh';age-=10.46;}
      else if(age<15.38){mode='burn';age-=13.26;}
      else {mode='idle';age-=15.38;}
    }
    const motion=!this.reducedMotion,tt=motion?age:0;
    for(const [bone,q] of this.boneRest)bone.quaternion.copy(q);
    this.scene.position.copy(this.rest.position);this.scene.quaternion.copy(this.rest.quaternion);this.scene.scale.copy(this.rest.scale);this.scene.visible=true;
    const face={jawOpen:0,smile:0,pucker:0,blinkLeft:0,blinkRight:0,browRaise:0,cheekRaise:0,tongueOut:0,tongueCurl:0};
    let yaw=0,bob=0,tilt=0,sx=1,sy=1;
    if(mode==='idle'){
      const blink=motion?pulse(3.7,3.78,3.83,3.96,tt%6):0;
      face.blinkLeft=face.blinkRight=blink;face.browRaise=motion?.065*(.5+.5*Math.sin(tt*1.1)):0;
      bob=motion?.012*Math.sin(tt*1.6):0;tilt=motion?.008*Math.sin(tt*1.3):0;
    }else if(mode==='laugh'){
      const env=pulse(.10,.38,2.10,2.65,age),laugh=env*Math.max(0,Math.sin((age-.4)*12));
      face.jawOpen=.08*env+.52*laugh;face.smile=.65*env;face.cheekRaise=.65*env;face.blinkLeft=.25*env;face.blinkRight=.20*env;face.browRaise=.25*env;
      bob=motion?.035*laugh:0;tilt=motion?-.025*env:0;
    }else if(mode==='tongue'){
      const grin=pulse(.05,.35,2.15,2.65,age),tongue=pulse(.65,.96,1.70,2.2,age);
      face.jawOpen=.45*grin;face.smile=.50*grin;face.cheekRaise=.25*grin;face.browRaise=.60*grin;
      face.tongueOut=tongue;face.tongueCurl=tongue*(.65+.20*Math.sin(tt*8));
      face.blinkLeft=.50*pulse(.35,.45,.61,.82,age);tilt=motion?-.035*grin:0;
    }else if(mode==='speak'){
      Object.assign(face,this.speechFace(age));face.blinkLeft=face.blinkRight=pulse(3.43,3.50,3.55,3.67,age);
      tilt=motion?.012*Math.sin(age*2.1):0;bob=motion?.008*Math.sin(age*3.5):0;
    }else if(mode==='turntable'){
      yaw=motion?TAU*clamp(age/8):0;
    }else if(mode==='burn'){
      if(motion){
        const rise=smooth(.12,.56,age),collapse=smooth(1.48,1.94,age);
        sx=(.06+.94*rise)*(1-.997*collapse);sy=(.025+.975*rise)*(1-.997*collapse);
        yaw=TAU*smooth(.88,1.48,age)+TAU*.65*smooth(1.48,1.94,age);
        face.jawOpen=.42*pulse(.92,1.04,1.27,1.57,age);face.smile=.40*pulse(.30,.56,1.4,1.8,age);face.browRaise=.20*pulse(.30,.56,1.4,1.8,age);
      }else this.scene.visible=age<1.9;
      if(age>=1.94)this.scene.visible=false;
    }
    if(this.reducedMotion){bob=0;tilt=0;}
    this.scene.rotation.y+=yaw;this.scene.rotation.z+=tilt;this.scene.position.y+=bob;this.scene.scale.multiplyScalar(sx);this.scene.scale.y=this.rest.scale.y*sy;
    // Small, coherent secondary motion through the exported skeleton, when present.
    // Expression controls remain independently editable morph targets.
    if(motion&&mode!=='burn'&&mode!=='turntable'){
      const rotate=(label,x,y,z)=>{const bone=Object.values(this.nodes).find(o=>o.isBone&&(o.name===label||o.name.toLowerCase()===label.toLowerCase()));if(bone)bone.quaternion.multiply(new Quaternion().setFromEuler(new Euler(x,y,z)));};
      rotate('UpperFunnel',.005*Math.sin(tt*1.6),0,.008*Math.sin(tt*1.3));
      rotate('Head',.010*Math.sin(tt*1.7),.008*Math.sin(tt*1.2),.012*Math.sin(tt*1.3));
      rotate('Crown',.012*Math.sin(tt*1.7-.35),0,.014*Math.sin(tt*1.3-.35));
    }
    if(this.faceOverride)Object.assign(face,this.faceOverride);
    this.applyFace(face);this.scene.updateMatrixWorld(true);
    this.last={mode,requestedMode:this.mode,time:age,face:{...face},yaw,visible:this.scene.visible,reducedMotion:this.reducedMotion};return this.last;
  }
  dispose(){this.disposed=true;}
}
