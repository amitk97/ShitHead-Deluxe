import * as THREE from 'three';
import {GLTFLoader} from './viewer/loaders/GLTFLoader.js';
import {CharacterController,MODES,clamp,smooth} from './character-controller.js';
const el=id=>document.getElementById(id),stage=el('stage'),loading=el('loading');
window.review={ready:false,error:null};
let renderer,environment,model,controller,animation=0,disposed=false;
try{
renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,preserveDrawingBuffer:true});
renderer.setPixelRatio(Math.min(devicePixelRatio||1,2));renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.NoToneMapping;renderer.setClearColor(0x0b111a,0);stage.prepend(renderer.domElement);
const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(31,1,.05,60),holder=new THREE.Group();scene.add(holder);
const ambient=new THREE.HemisphereLight(0xe8e2d6,0x3d2412,.70);scene.add(ambient);
const key=new THREE.DirectionalLight(0xffe9cb,1.0);key.position.set(-3,5,4);scene.add(key);
const fill=new THREE.DirectionalLight(0xcbd9ee,.26);fill.position.set(3,2,4);scene.add(fill);
const rim=new THREE.DirectionalLight(0xffbb62,.60);rim.position.set(3,4,-3);scene.add(rim);
const baseLight=new THREE.PointLight(0xff8c2d,0,8,2);baseLight.position.set(0,.10,.30);scene.add(baseLight);
const studio=new THREE.Scene();studio.background=new THREE.Color(.025,.027,.03);
for(const [pos,size,color]of[[[-4,5,3],[3,4],[.75,.66,.50]],[[3,2,2],[2,3],[.24,.29,.36]],[[2,4,-3],[2,4],[.60,.28,.08]]]){const p=new THREE.Mesh(new THREE.PlaneGeometry(...size),new THREE.MeshBasicMaterial({color:new THREE.Color(...color),side:THREE.DoubleSide}));p.position.set(...pos);p.lookAt(0,1.8,0);studio.add(p)}
const pmrem=new THREE.PMREMGenerator(renderer);environment=pmrem.fromScene(studio,.08);scene.environment=environment.texture;pmrem.dispose();studio.traverse(o=>{o.geometry?.dispose();o.material?.dispose()});
const [gltf,words]=await Promise.all([new GLTFLoader().loadAsync('./mascot.glb'),fetch('./voice-timing.json').then(r=>{if(!r.ok)throw new Error('Voice timing could not load');return r.json()})]);
model=gltf.scene;holder.add(model);model.traverse(o=>{if(o.isMesh){o.frustumCulled=false;for(const m of Array.isArray(o.material)?o.material:[o.material]){if('envMapIntensity'in m)m.envMapIntensity=.32;}}});
const reduced=matchMedia('(prefers-reduced-motion: reduce)');controller=new CharacterController(gltf,{words,reducedMotion:reduced.matches});
const voice=new Audio('./mascot-voice.mp3'),burnSound=new Audio('./draft-burn.wav');voice.preload=burnSound.preload='none';voice.volume=.70;burnSound.volume=.65;voice.muted=burnSound.muted=true;
let clock=0,playing=!reduced.matches,mode='idle',sound=false,last=performance.now(),yaw=0,elevation=0,closeup=false,wire=false,relit=false,hidden=false,manualFace=false,lastDraw=0,drawTimes=[],drawCount=0;
const maxTimes=120;const statusNames={idle:'Idle',speak:'Speaking',laugh:'Laugh',tongue:'Cheeky',burn:'Shitstorm',turntable:'Turntable',demo:'Full sequence'};
const caption={idle:'Drag to turn the character. Sound is off until you enable it.',speak:'“Welcome to ShitHead Deluxe. Nice cards. Shame if something happened to them.”',laugh:'A cheeky laugh, with cheeks, jaw and teeth moving together.',tongue:'A rooted tongue rolls out through the mouth and retracts.',burn:'The whole character gathers, spins and contracts into the pile.',turntable:'One complete turn. Drag to change the viewing angle.',demo:'Idle, speech, cheeky reaction, laugh and Shitstorm.'};
function stopAudio(){for(const a of[voice,burnSound]){a.pause();a.currentTime=0;}}
function audioAt(t,autoplay=false){
  const offset=mode==='demo'?1.2:0,start=mode==='demo'?13.26:0;
  const speaking=(mode==='speak'||mode==='demo')&&t>=offset&&t<offset+6.46;
  const burning=(mode==='burn'||mode==='demo')&&t>=start&&t<start+2.12;
  for(const [a,active,time]of[[voice,speaking,t-offset],[burnSound,burning,t-start]]){
    if(sound&&active&&autoplay&&!hidden){if(Math.abs(a.currentTime-time)>.13)a.currentTime=Math.max(0,time);if(a.paused)a.play().catch(()=>{el('caption').textContent='Audio playback needs another tap on Sound.'})}
    else if(!a.paused)a.pause();
  }
}
const debris=new THREE.Group();scene.add(debris);const debrisNodes=[];
// Fold attachment is chosen from real model vertices, excluding the face and crown.
model.updateMatrixWorld(true);let candidates=[];let surface;
model.traverse(o=>{if(o.isMesh&&(!surface||o.geometry.attributes.position.count>surface.geometry.attributes.position.count))surface=o});
if(surface){const p=surface.geometry.attributes.position,normal=surface.geometry.attributes.normal,v=new THREE.Vector3();for(let i=0;i<p.count;i+=11){v.fromBufferAttribute(p,i).applyMatrix4(surface.matrixWorld);if(v.y>.35&&v.y<2.02&&v.length()>.3)candidates.push(v.clone());}}
let rng=7391;function rand(){rng=(Math.imul(1664525,rng)+1013904223)>>>0;return rng/4294967296;}
function paperTexture(i){const c=document.createElement('canvas');c.width=128;c.height=180;const g=c.getContext('2d');g.fillStyle='#ede3cb';g.fillRect(0,0,128,180);const grad=g.createLinearGradient(0,0,0,180);grad.addColorStop(0,'#ffcf8610');grad.addColorStop(.65,'#ff9c3422');grad.addColorStop(1,'#9d3a00aa');g.fillStyle=grad;g.fillRect(0,0,128,180);g.strokeStyle='#5c2b10';g.lineWidth=7;g.strokeRect(1,1,126,178);const ranks=['10','A','K','Q'],suits=['♥','♥','♠','♠'];g.fillStyle=i<2?'#a51519':'#191313';g.font='bold 34px serif';g.fillText(ranks[i],12,37);g.font='28px serif';g.fillText(suits[i],14,66);g.font='58px serif';g.fillText(suits[i],34,125);const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;return t;}
const paperMaps=Array.from({length:4},(_,i)=>paperTexture(i));const paperMats=paperMaps.map(map=>new THREE.MeshStandardMaterial({map,roughness:.80,side:THREE.DoubleSide}));
const sludgeMat=new THREE.MeshStandardMaterial({color:0x683318,roughness:.28,metalness:0,envMapIntensity:.6});const emberMat=new THREE.MeshBasicMaterial({color:0xf7a644,transparent:true});
for(let i=0;i<42;i++){const type=i%7<4?'paper':i%7<6?'sludge':'ember';let geo,mat;
 if(type==='paper'){const shape=new THREE.Shape();shape.moveTo(-.055,-.09);shape.lineTo(.045,-.075);shape.lineTo(.052,-.015);shape.lineTo(.031,.005);shape.lineTo(.055,.07);shape.lineTo(.01,.087);shape.lineTo(-.036,.061);shape.lineTo(-.052,.018);shape.closePath();geo=new THREE.ShapeGeometry(shape);const p=geo.attributes.position,uv=geo.attributes.uv;for(let n=0;n<p.count;n++)uv.setXY(n,p.getX(n)/.11+.5,p.getY(n)/.18+.5);mat=paperMats[i%4];}
 else if(type==='sludge'){geo=new THREE.SphereGeometry(.028,10,8);const p=geo.attributes.position;for(let n=0;n<p.count;n++){const yy=p.getY(n)/.028;p.setXYZ(n,p.getX(n)*(1-.25*Math.max(0,yy)),p.getY(n)*(yy>0?1.65:1),p.getZ(n)*(1-.25*Math.max(0,yy)));}geo.computeVertexNormals();mat=sludgeMat;}
 else{geo=new THREE.SphereGeometry(.011,6,4);mat=emberMat;}
 const mesh=new THREE.Mesh(geo,mat);debris.add(mesh);const anchor=candidates.length?candidates[Math.floor(rand()*candidates.length)].clone():new THREE.Vector3(Math.sin(i)*.5,.4+rand()*1.3,Math.cos(i)*.5);debrisNodes.push({mesh,anchor,type,release:.93+rand()*.36,speed:1.5+rand()*1.1,spin:rand()*6.28,scale:.55+rand()*.7});}
const glowCanvas=document.createElement('canvas');glowCanvas.width=glowCanvas.height=128;const gg=glowCanvas.getContext('2d'),gradient=gg.createRadialGradient(64,64,1,64,64,63);gradient.addColorStop(0,'#ffcb6aaa');gradient.addColorStop(.4,'#ea72114d');gradient.addColorStop(1,'#ea721100');gg.fillStyle=gradient;gg.fillRect(0,0,128,128);const glowTex=new THREE.CanvasTexture(glowCanvas),glow=new THREE.Mesh(new THREE.PlaneGeometry(3.6,3.6),new THREE.MeshBasicMaterial({map:glowTex,transparent:true,depthWrite:false,side:THREE.DoubleSide,blending:THREE.AdditiveBlending}));glow.rotation.x=-Math.PI/2;glow.position.y=.015;scene.add(glow);
function sampleDebris(status){const t=status.time,active=status.mode==='burn'&&!reduced.matches&&t<2.12;debris.visible=glow.visible=active;baseLight.intensity=active?2.2*(1-smooth(1.65,2.12,t)):0;if(!active)return;
 glow.material.opacity=smooth(0,.25,t)*(1-smooth(1.62,2.12,t));const rot=new THREE.Matrix4().makeRotationY(status.yaw);
 for(const p of debrisNodes){const age=t-p.release;p.mesh.visible=age>-.18&&age<.85;if(!p.mesh.visible)continue;const start=p.anchor.clone();const releaseYaw=Math.PI*2*smooth(.88,1.48,p.release);start.applyAxisAngle(new THREE.Vector3(0,1,0),age<0?status.yaw:releaseYaw);if(age>0){const tangent=new THREE.Vector3(start.z,0,-start.x).normalize();p.mesh.position.copy(start).addScaledVector(tangent,p.speed*age);p.mesh.position.y+=1.0*age-.85*age*age;p.mesh.position.addScaledVector(new THREE.Vector3(start.x,0,start.z).normalize(),.16*age*age);}else p.mesh.position.copy(start);p.mesh.rotation.set(age*6+p.spin,age*8,age*3+p.spin);const fade=smooth(-.18,-.02,age)*(1-smooth(.55,.85,age));p.mesh.scale.setScalar(p.scale*fade);if(p.type==='sludge')p.mesh.scale.y*=1+Math.max(0,age)*1.4;}
}
function cameraPose(){const target=new THREE.Vector3(-.13,closeup?2.62:1.85,0),aspect=Math.max(.2,stage.clientWidth/stage.clientHeight);let distance=closeup?Math.max(6.35,4.8/aspect):Math.max(8.4,5.0/aspect);camera.position.set(Math.sin(yaw)*Math.cos(elevation)*distance,target.y+Math.sin(elevation)*distance,Math.cos(yaw)*Math.cos(elevation)*distance);camera.lookAt(target);camera.aspect=aspect;camera.updateProjectionMatrix();}
function draw(){const before=performance.now(),status=controller.sample(clock);sampleDebris(status);cameraPose();renderer.render(scene,camera);el('mode-label').textContent=statusNames[status.mode]||status.mode;el('seek').value=String(clock);el('time').value=clock.toFixed(2)+' / '+MODES[mode].toFixed(2);drawCount++;drawTimes.push(performance.now()-before);if(drawTimes.length>maxTimes)drawTimes.shift();lastDraw=performance.now();return status;}
function resize(){if(disposed)return;renderer.setSize(stage.clientWidth,stage.clientHeight);draw();}const resizeObserver=new ResizeObserver(resize);resizeObserver.observe(stage);
function setMode(name,{play=true}={}){stopAudio();controller.setMode(name);mode=name;clock=0;manualFace=false;playing=play&&!reduced.matches;el('seek').max=MODES[name];el('caption').textContent=caption[name];el('pause').textContent=playing?'Pause':'Play';draw();audioAt(clock,playing);return review.state();}
function pause(value){playing=!value;el('pause').textContent=playing?'Pause':'Play';if(!playing){voice.pause();burnSound.pause();}else audioAt(clock,true);}
for(const name of['speak','laugh','tongue','burn','turntable','demo','idle'])el(name).onclick=()=>setMode(name);
el('pause').onclick=()=>{if(!playing&&clock>=MODES[mode]-.001)clock=0;pause(playing)};
el('sound').onclick=()=>{sound=!sound;voice.muted=burnSound.muted=!sound;el('sound').textContent=sound?'Sound on':'Sound off';el('sound').setAttribute('aria-pressed',String(sound));audioAt(clock,playing);};
for(const button of document.querySelectorAll('[data-view]'))button.onclick=()=>{const poses={front:[0,0],quarter:[Math.PI/4,0],side:[Math.PI/2,0],back:[Math.PI,0],underside:[Math.PI/5,-.90]};[yaw,elevation]=poses[button.dataset.view];setMode('idle',{play:false});};
el('closeup').onclick=()=>{closeup=!closeup;el('closeup').setAttribute('aria-pressed',String(closeup));draw();};
el('relight').onclick=()=>{relit=!relit;key.position.set(relit?3:-3,relit?2:5,4);rim.position.x=relit?-3:3;el('relight').setAttribute('aria-pressed',String(relit));draw();};
el('wire').onclick=()=>{wire=!wire;model.traverse(o=>{if(o.isMesh)for(const m of Array.isArray(o.material)?o.material:[o.material])m.wireframe=wire});el('wire').setAttribute('aria-pressed',String(wire));draw();};
el('seek').oninput=()=>{clock=+el('seek').value;pause(true);draw();audioAt(clock,false);};
let dragging=false,px=0,py=0;renderer.domElement.addEventListener('pointerdown',e=>{dragging=true;px=e.clientX;py=e.clientY;renderer.domElement.setPointerCapture(e.pointerId)});renderer.domElement.addEventListener('pointermove',e=>{if(!dragging)return;yaw-=(e.clientX-px)*.008;elevation=clamp(elevation+(e.clientY-py)*.005,-1.15,1.15);px=e.clientX;py=e.clientY;draw()});for(const name of['pointerup','pointercancel'])renderer.domElement.addEventListener(name,()=>dragging=false);
function tick(now){if(disposed)return;animation=requestAnimationFrame(tick);const dt=Math.min(.05,Math.max(0,(now-last)/1000));last=now;if(!playing||hidden)return;clock+=dt;if(mode==='idle'){clock%=6;}else if(clock>=MODES[mode]){clock=MODES[mode];pause(true);}draw();audioAt(clock,playing);}
function onReduced(e){controller.reducedMotion=e.matches;if(e.matches)pause(true);draw();}reduced.addEventListener('change',onReduced);
document.addEventListener('visibilitychange',()=>{hidden=document.hidden;last=performance.now();if(hidden){voice.pause();burnSound.pause();}else if(playing)audioAt(clock,true)});
loading.remove();document.querySelectorAll('button[disabled]').forEach(b=>b.disabled=false);el('pause').textContent=playing?'Pause':'Play';
const review=window.review={ready:true,gltf,scene,camera,holder,renderer,controller,
 pose(a=0,e=0){yaw=a;elevation=clamp(e,-1.2,1.2);draw();return this.state();},
 setMode(name){return setMode(name,{play:false});},seek(seconds){clock=clamp(seconds,0,MODES[mode]);pause(true);draw();return this.state();},
 setFace(face){controller.setFace(face);manualFace=!!face;pause(true);draw();return this.state();},
 closeup(value=true){closeup=!!value;el('closeup').setAttribute('aria-pressed',String(closeup));draw();return this.state();},
 relight(value=true){if(relit!==!!value)el('relight').click();return this.state();},
 capture(value=true){document.body.classList.toggle('capture',!!value);resize();},
 play(){pause(false);},pause(){pause(true);},
 state(){return{ready:true,mode,clock,playing,yaw,elevation,closeup,wire,relit,sound,reducedMotion:reduced.matches,face:controller.last.face,visible:controller.last.visible,morphMeshes:controller.morphs.length,morphNames:[...new Set(controller.morphs.flatMap(m=>Object.keys(m.morphTargetDictionary)))],drawCount,meanDrawMs:drawTimes.reduce((a,b)=>a+b,0)/(drawTimes.length||1),renderer:renderer.info.render,bodyBounds:new THREE.Box3().setFromObject(model).getSize(new THREE.Vector3()).toArray(),particleCount:debrisNodes.filter(p=>debris.visible&&p.mesh.visible).length,voiceCurrentTime:voice.currentTime,voicePaused:voice.paused};},
 dispose(){if(disposed)return;disposed=true;cancelAnimationFrame(animation);resizeObserver.disconnect();stopAudio();controller.dispose();const resources=new Set();scene.traverse(o=>{if(o.geometry)resources.add(o.geometry);for(const m of Array.isArray(o.material)?o.material:[o.material])if(m){resources.add(m);for(const value of Object.values(m))if(value?.isTexture)resources.add(value)}});for(const resource of resources)resource.dispose();environment.dispose();renderer.dispose();reduced.removeEventListener('change',onReduced);}
};
addEventListener('pagehide',event=>{if(!event.persisted)review.dispose();else{hidden=true;voice.pause();burnSound.pause();}});addEventListener('pageshow',()=>{hidden=false;last=performance.now();});
resize();draw();animation=requestAnimationFrame(tick);
}catch(error){window.review.error=String(error.stack||error);loading.textContent='The character could not load. Keep mascot.html beside its model and viewer files, then reload.';el('mode-label').textContent='Load error';console.error(error);}
